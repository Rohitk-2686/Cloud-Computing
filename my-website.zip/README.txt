S3 Static Website - Ready to Upload

Files:
- index.html (Home with header, footer, image)
- about.html
- contact.html (static demo form)
- error.html (custom 404)
- images/banner.jpg

How to host on Amazon S3:
1) Create an S3 bucket (unique name). Uncheck "Block all public access".
2) Upload all files/folders preserving the structure.
3) In Properties -> Static website hosting:
   - Enable
   - Index document: index.html
   - Error document: error.html
4) Set a bucket policy for public read (replace BUCKET_NAME below).

Sample bucket policy (minimal public read):
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "PublicReadGetObject",
      "Effect": "Allow",
      "Principal": "*",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::BUCKET_NAME/*"
    }
  ]
}
